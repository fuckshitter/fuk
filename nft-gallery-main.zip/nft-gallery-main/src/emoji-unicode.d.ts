declare module 'emoji-unicode'
