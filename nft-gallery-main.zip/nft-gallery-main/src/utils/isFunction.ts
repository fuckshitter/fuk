const isFunction = (fn: any) => typeof fn === 'function';

export default isFunction
