const isShareMode = !(window === window.parent)

export default isShareMode
