<template>
  <div class="box container" id="FourZeroFour">
    <p class="title">End of The Internet 🔌</p>
    <p class="subtitle">You've probably found part of our App, we did not engineer!</p>
    <p class="subtitle">Go back or read book</p>
    <p class="subtitle">If you think this should't happen, report us by
      <a target="_blank" rel="noopener noreferrer"  href="https://github.com/kodadot/nft-gallery/issues/new?assignees=&labels=bug&template=bug_report.md&title=">creating bug issue with steps to reproduce and screenshot.</a></p>
  </div>
</template>
<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';

@Component({})
export default class FourZeroFour extends Vue {}
</script>
