<template>
<div>
  Selection Works!
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';

@Component
export default class WithKeyring extends Vue {


}
</script>
