declare module 'vue-audio-visual'
