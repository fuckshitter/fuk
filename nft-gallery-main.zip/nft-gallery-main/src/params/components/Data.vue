<template>
  <div>Data works!</div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';

@Component
export default class Data extends Vue {
}
</script>
